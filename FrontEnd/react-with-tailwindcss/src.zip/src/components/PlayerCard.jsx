import React from 'react'

function PlayerCard() {
  return (
    <div>PlayerCard</div>
  )
}

export default PlayerCard;

