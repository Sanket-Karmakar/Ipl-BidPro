import React from 'react'

function PrivateRoute() {
  return (
    <div>PrivateRoute</div>
  )
}

export default PrivateRoute;